document.addEventListener("DOMContentLoaded", () => {
    const sections = [
        document.getElementById("section1"),
        document.getElementById("section2"),
        document.getElementById("section3"),
        document.getElementById("section5"),
        document.getElementById("section6"),
        document.getElementById("section7"),
        document.getElementById("section8")
    ];

    let currentIndex = 0;

    // Hide all except first
    sections.forEach((sec, i) => {
        sec.style.display = i === 0 ? "block" : "none";
    });

    // Select all NEXT buttons
    const nextButtons = document.querySelectorAll(".nextBtn");

    nextButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            sections[currentIndex].style.display = "none";

            if (currentIndex < sections.length - 1) {
                currentIndex++;
            }
            sections[currentIndex].style.display = "block";

            sections[currentIndex].scrollIntoView({ behavior: "smooth" });
        });
    });

    // Handle Back buttons
    const backBtns = document.querySelectorAll(".backBtn");
    backBtns.forEach(btn => {
        btn.addEventListener("click", () => {
            sections[currentIndex].style.display = "none";
            if (currentIndex > 0) currentIndex--;
            sections[currentIndex].style.display = "block";
            window.scrollTo(0, 0); // scroll to top
            sections[currentIndex].scrollIntoView({ behavior: "smooth" });
        });
    });
});

