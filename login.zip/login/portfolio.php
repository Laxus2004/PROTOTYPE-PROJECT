<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio</title>
    <link rel="stylesheet" href="port.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <h1>THE SEIGES OF IMPERIALS</h1>
    <div class="container" id="section1">
        <h2>Section 1 - Game Overview</h2>
        <form method="post" action="">
            <div class="info-group">
                <h3>Game Concept</h3>
                <p>The Seiges of Imperials is a 2D pixel-art Action-RPG with high-stakes survival elements.
                    The core loop involves taking on challenging Missions with specific objectives or
                    surviving against continuous waves of enemies in the challenging Survival Mode, all while
                    managing limited resources and pursuing character progression.
                </p>
                <img src="../login/imgportfolio/1.png" alt="Game Title">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Genre</h3>
                <p>2D Action RPG / Fantasy <br> Survival/Horror
                </p>
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Target Audience</h3>
                <p>
                    Teens/Adults (Specifically players who enjoy challenging, dark-fantasy themes, character
                    progression, and retro-style pixel art games).
                </p>
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Game Flow Summary</h3>
                <p>
                    The player controls their character in a 2D side-scrolling environment, moving horizontally to
                    the left or right. The primary loop is defined by the chosen mode: <br>
                    Mission Mode: Completing all tasks
                    progresses the level or ends the mission final objective. <br>
                    Survival Mode: The player attempts to survive against continuously spawning and increasingly
                    difficult enemy waves until they are defeated.
                </p>
                <img src="../login/imgportfolio/2.png" alt="">
                <img src="../login/imgportfolio/3.png" alt="">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Targer Audience</h3>
                <p>
                    Teens/Adults (Specifically players who enjoy challenging, dark-fantasy themes, character
                    progression, and retro-style pixel art games).
                </p>
            </div>
        </form>
        <button class="nextBtn">Next</button>
        <button><a href="homepage.php">Back to HomePage</a></button>

    </div>

    <div class="container" id="section2" style="display: none;">
        <h2>Section 2 - Gameplay and Mechanics</h2>
        <form method="post" action="">
            <div class="info-group">
                <h3>Gameplay</h3>
                <p>
                    Game progression is primarily driven by successfully completing missions in Mission Mode and Survival Mode.
                    Mission Mode: Successful completion of a mission unlocks the next narrative objective.
                    Survival Mode: Progression is measured by the wave number reached and the high score
                    achieved.
                </p>
                <img src="../login/imgportfolio/4.png" alt="Game Title">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Mission/challenge Structure</h3>
                <p>Missions are structured scenarios with a specific environment (Biome) and a clearly defined
                    objective set.
                    Elimination: Defeat a set number of specific enemy types ("Defeat 8 Skeletons"). If the player's
                    hero dies, the mission fails and must be restarted. However, coins are instantly saved and are not
                    lost upon death.    
                    Collection: Defeat enemies to make them drop coins use buying unique characters.
                </p>
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Play Flow</h3>
                <p>
                    Preparation (Hub/Menu): The player must first choose the Mode (Mission or Survival). Next,
                    they select a Hero Type (Shinobi, Vampire, or Ghost), and finally, they choose one of the three
                    available characters within that type. <br>
                    Mission Selection: Player selects a Mission or the Survival Mode, choosing the map and
                    difficulty. <br>
                    Deployment: The hero spawns at the mission start point. <br>
                    Action/Combat Loop: Player engages enemies, manages hero health/resources, and progresses
                    toward the objective. Movement and combat are direct and responsive, focusing on player
                    positioning and timing. <br>
                    Resolution (Failure): If the hero dies, a "Mission Failed" screen appears. The player will restart
                    the game, potentially can keep the resources.
                </p>
                <img src="../login/imgportfolio/4.png" alt="Game">
                <img src="../login/imgportfolio/5.png" alt="Game">
                <img src="../login/imgportfolio/6.png" alt="Game">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Physics</h3>
                <p>
                    The game uses a 2D Side-Scrolling Physics Model with realistic but stylized gravity.
                    Gravity: Standard physics applies; characters and objects fall at a consistent rate.
                    Collision: Player, enemies, and interactive objects have collision boxes to prevent overlap.
                </p>
                <img src="../login/imgportfolio/7.png" alt="Game">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Options Screen</h3>
                <p>
                    Player adjusts technical settings (Volume, Resolution) and gameplay preferences.
                </p>
                <img src="../login/imgportfolio/8.png" alt="Game">
            </div>
        </form>
        <button class="nextBtn">Next</button>
        <button class="backBtn">Back</button>
        <button><a href="homepage.php">Back to HomePage</a></button>
    </div>

    <div class="container" id="section3" style="display: none;">
        <h2>Section 3 - Story, Setting and characters</h2>
        <form method="post" action="">
            <div class="info-group">
                <h3>Back story</h3>
                <p>The Imperials were a strong but peaceful kingdom. Suddenly, monsters like goblins,
                    skeletons, and strange flying eyes attacked. They came through magic doorways called
                    dimensional rifts. The Imperial army was quickly destroyed. In a panic, the remaining leaders
                    begged for help from very powerful people who had promised long ago to protect the land. 
                </p>
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Cut Scenes</h3>
                <p>
                    Cut scenes will be short, simple, pixel-art animations shown before and after major fights.
                </p>
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Character #1</h3>
                <p>
                    Fighter (The Fast Attacker)
                </p>
                <img src="../login/imgportfolio/10.png" alt="Game">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Character #2</h3>
                <p>
                    Samurai (The Balanced Warrior)
                </p>
                <img src="../login/imgportfolio/11.png" alt="Game">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Character #3</h3>
                <p>
                    Shinobi (The Stealth Assassin)
                </p>
                <img src="../login/imgportfolio/12.png" alt="Game">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Character #4</h3>
                <p>
                    Converted (Vampire)
                </p>
                <img src="../login/imgportfolio/13.png" alt="Game">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Character #5</h3>
                <p>
                    Countess (Vampire)
                </p>
                <img src="../login/imgportfolio/14.png" alt="Game">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Character #6</h3>
                <p>
                    Vampire Girl (Vampire)
                </p>
                <img src="../login/imgportfolio/15.png" alt="Game">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Character #7</h3>
                <p>
                    Gotoku (Ghost)
                </p>
                <img src="../login/imgportfolio/16.png" alt="Game">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Character #8</h3>
                <p>
                    Onre (Ghost)
                </p>
                <img src="../login/imgportfolio/17.png" alt="Game">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Character #9</h3>
                <p>
                    Yunrie (Ghost)
                </p>
                <img src="../login/imgportfolio/18.png" alt="Game">
            </div>
        </form>
        <button class="nextBtn">Next</button>
        <button class="backBtn">Back</button>
        <button><a href="homepage.php">Back to HomePage</a></button>

    </div>
    
    <div class="container" id="section5" style="display: none;">
        <h2>Section 5 - Interface</h2>
        <form method="post" action="">
            <div class="info-group">
                <h3>Visual System</h3>
                <p>The game’s visual presentation features detailed 2D environments, animated characters,
                and layered backgrounds that emphasize the imperial-fantasy atmosphere.
                </p>
                <img src="../login/imgportfolio/19.png" alt="Game">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Rendering System</h3>
                <p>
                    Built on Godot’s 2D Renderer, supporting parallax backgrounds and optimized sprite
                    layering for seamless animation and smooth performance across devices.
                </p>
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Audio</h3>
                <p>
                    Music: Background themes for menu and battle sequences. <br>
                    Sound Effects: Weapon attacks, coin collection, menu clicks, and environmental feedback.
                    Managed through the project’s default audio bus layout for balanced volume and fade
                    transitions.
                </p>
                <img src="../login/imgportfolio/20.png" alt="Game">
            </div>
        </form>
        <button class="nextBtn">Next</button>
        <button class="backBtn">Back</button>
        <button><a href="homepage.php">Back to HomePage</a></button>
    </div>

    <div class="container" id="section6" style="display: none;">
        <h2>Section 6 - Artificial Intelligence</h2>
        <form method="post" action="">
            <div class="info-group">
                <h3>Opponent AI</h3>
                <p>
                   <h4>Corrupted Mushroom</h4>
                </p>
                <img src="../login/imgportfolio/23.png" alt="Game">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <p>
                   <h4>Goblin</h4>
                </p>
                <img src="../login/imgportfolio/24.png" alt="Game">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <p>
                   <h4>Skeleton</h4>
                </p>
                <img src="../login/imgportfolio/25.png" alt="Game">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <p>
                   <h4>Flying Eye</h4>
                </p>
                <img src="../login/imgportfolio/26.png" alt="Game">
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Character Behaviors Enemy AI</h3>
                <p>
                    Corrupted Mushroom: Stays still, only attacks if you are next to it. <br>
                    Goblin: Runs fast at the hero in big groups, attacks quickly. <br>
                    Skeleton: Moves slowly, has high defense (hard to hit), and hits very hard. <br>
                    Flying Eye: Floats far away and shoots magic bolts at the hero from a distance.
                </p>
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Player and Collision Detection</h3>
                <p>
                    AI movement is guided through navigation polygons and path nodes built within each level.
                    Enemies calculate routes using Godot’s built-in Navigation2D system, ensuring smooth
                    pursuit and obstacle avoidance. Path recalculation occurs dynamically when obstacles or
                    player positions change.
                </p>
                <img src="../login/imgportfolio/22.png" alt="Game">
            </div>
        </form>
        <button class="nextBtn">Next</button>
        <button class="backBtn">Back</button>
        <button><a href="homepage.php">Back to HomePage</a></button>
    </div>

    <div class="container" id="section7" style="display: none;">
        <h2>Section 7 - Technical</h2>
        <form method="post" action="">
            <div class="info-group">
                <h3>Target Hardware</h3>
                <p>
                    The game only needs a basic computer with at least 2 GB of memory, any graphics card, and an internet connection only for the first download.
                </p>
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Development hardware and software</h3>
                <p>
                    Hardware Used by Developers: Standard Windows PC or laptop. Minimum 8 GB RAM for
                    smooth engine operation.
                    Software Tools: Game Engine: Godot Engine Image Editing:
                </p>
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Game Engine</h3>
                <p>
                    The project uses Godot Engine (Version 4.x). 2D Engine for gameplay and rendering. Built-in
                    Physics, Audio, and Navigation systems. Lightweight and open-source. Cross-platform export
                    capability.
                </p>
            </div>
        </form>
        <form method="post" action="">
            <div class="info-group">
                <h3>Scripting Language</h3>
                <p>
                    The primary scripting language is GDScript, Godot’s native language. Optional secondary
                    scripting in C# if needed for performance.
                </p>
            </div>
        </form>
        <button class="nextBtn">Next</button>
        <button class="backBtn">Back</button>
        <button><a href="homepage.php">Back to HomePage</a></button>
    </div>

    <div class="container" id="section8" style="display: none;">
        <h2>Team Members</h2>
        <form method="post" action="">
            <div class="info-group">
                <ul class="members">
                    <li>Har Jay Rallos</li>
                    <li>Clent Andrew Mendoza</li>
                    <li>Arvin Ochia</li>
                    <li>Jaspher Arnado</li>
                    <li>Elven Casipong</li>
                </ul>
            </div>
        </form>
        <div> 
            <br><br>
            <h2>Thank You and Goodbye</h2>
        </div>
        <button><a href="homepage.php">Back to HomePage</a></button>
    </div>

    <script src="port.js"></script>
</body>
</html>