<?php
session_start();
include("connect.php");

$userFullName = "";

// Get user name once
if (isset($_SESSION['email'])) {
    $email = $_SESSION['email'];
    $query = mysqli_query($conn, "SELECT firstName, lastName FROM users WHERE email='$email'");
    if ($row = mysqli_fetch_assoc($query)) {
        $userFullName = $row['firstName'] . ' ' . $row['lastName'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="/login/homepage.css">
</head>
<body>
    <div class="user" >
      <nav class="navbar">
        <ul>
            <li><p><?php echo $userFullName; ?></p></li>
            <li><a href="#home">Home</a></li>
            <li><a href="#portfolio">Portfolio</a></li>
            <li><a href="#about">About Me</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    </div>

    <section id="home">
        <div class="container-h">
            <img src="/login/images/me3.png" alt="me">
            <div class="home">
                <h1>What's up?</h1><br><br><br><br><br>
                <p>
                    "Web Development is the focus. Chill vibes, serious code. That’s the mission."
                </p>
            </div>
        </div>
    </section>
    
    <section id="portfolio">
        <div class="container-p">
            <div class="cons">
                <h1>APPDEV PORTFOLIO</h1>
            </div>
            <div class="image-box">
                <img src="/login/imgportfolio/1.png" alt="portfolio image 1">
            </div>
            <a class="btn-p" href="portfolio.php">View Portfolio</a>
        </div>
    </section>
    
    <section id="about">
        <div class="container-a">
            <div class="abt">
                <h1>About Me</h1>
            </div>
            <div class="row">
                <div class="box">
                    <h4>Student</h4>
                    <p><br>University Of The Visayas</p>
                    <img src="/login/images/uv.png" alt="">
                </div>
                <div class="box">
                    <h4>Program</h4>
                    <p><br>Bachelor of Science in Information Technology</p>
                    <p>3rd Year</p><br>
                    <img src="/login/images/it.png" alt="">
                </div>
                <div class="box">
                    <h4>Focus</h4>
                    <p><br>Web Development</p> <br><br><br>
                    <img src="/login/images/web.png" alt="">
                </div>
            </div>
            <div class="row">
                <div class="box">
                    <h4>Hobby</h4>
                    <p><br>Gaming - Valorant</p><br><br>
                    <img src="/login/images/valo.png" alt="">
                </div>
                <div class="box">
                    <h4>Hobby</h4>
                    <p><br>Watching Anime</p> <br> <br>
                    <img src="/login/images/op.png" alt="">
                </div>
                <div class="box">
                    <h4>Hobby</h4>
                    <p><br>Watching Movie</p> <br><br><br>
                    <img src="/login/images/tulsa.png" alt="">
                </div>
            </div>
        </div>
    </section>
            
    <section id="contact">
        <div class="container-c">
            <div class="cons">
                <h1>Contact Me</h1>
                <p>Any questions or feedback? Just write me a message!</p>
            </div>
            <form method="post" action="">
                <div class="input-group">
                    <input type="text" name="name" placeholder="Your Name">
                </div>
                <div class="input-group">
                    <input type="email" name="email" placeholder="Your Email">
                </div>
                <div class="input-group">
                    <textarea name="message" rows="1" placeholder="Your Message"></textarea> 
                </div>
                <div class="input-group">
                    <button type="button" class="btn-c">Send Message</button>
                </div>
            </form>
            <p>----------or----------</p>
            <div class="icons">
                <i class="fab fa-facebook-f"></i>
                <i class="fab fa-twitter"></i>
                <i class="fas fa-phone"></i>
                <i class="fab fa-linkedin-in"></i>
            </div>
        </div>
    </section>

    <button id="scrollTopBtn" title="Go to top">↑</button>

    <script src="homepage.js"></script>
</body>
</html>